import numpy as np #para vectores y matrices
import matplotlib.pyplot as plt #para las gráficas
import math
plt.style.use("bmh")

np.linspace(-1000, 1000, 100)

N = 25
y = np.zeros(N)

def coordenadas(grid_min, grid_max):
    x = int(input("x:"))
    y = int(input("y:"))
    return q_loc

# Determinar el rango /Cambiar cuando el código ya sirva
grid_min = -10
grid_max = 6

# LINSPACE ES UN ARREGLO EN EL QUE DEFINES DONDE EMPIEZA , ACABA Y SU TAMAÑO
x = np.linspace(grid_min, grid_max, N)
y = np.linspace(grid_min, grid_max, N)

# Esta función MESHGRID coloca líneas de cuadrícula definidas por el usuario 
# En gráficos bidimensionales y tridimensionales
X, Y = np.meshgrid(x, y)

#Constante 
k_e=8987539422

def carga():
    c = float(input("Ingrese la carga (solo el valor sin elevar):"))
    x = float(input("Ingrese el orden de magnitud al que quiera elevar el exponencial:"))
    q = c*math.exp(x)
    return q
    #Q ES LA CARGA

# Determinar las cargas 
q=carga()
q_loc=coordenada(grid_min, grid_max)

q2=carga()
q2_loc=coordenada(grid_min, grid_max)

#AQUÍ QUIEN SABE¿?
rel = np.divide(X_new, r)
angles = np.arccos(rel)

# Matriz 1/r para los componentes
    r_1_2 = r_2**-1

mcos = np.cos(angles)
msin = np.sin(angles)

# Componentes de cda punto
Ex, Ey = (k_e*q*r_1_2*mcos)*(k_e*q*r_1_2*msin)
Ex2, Ey2 = 

Ex_t = Ex+Ex2
Ey_t = Ey+Ey2

# La magnitud
mags = (Ex_t**2+Ey_t**2)**(1/2)

X_new = X-q_loc[0]
Y_new = Y-q_loc[1]



